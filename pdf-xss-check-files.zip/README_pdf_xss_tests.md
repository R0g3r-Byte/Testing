# PDF JavaScript / XSS Upload Test Set

Six PDFs, each using a **different JavaScript execution trigger**. Different
viewers honour different triggers, so testing the whole set is how you
establish whether *any* execution path exists in the target's renderer — a
single file proves nothing if it happens to hit a trigger that viewer ignores.

The payload in every file is benign: a popup showing a marker and the
document's URL/domain. Nothing destructive. Swap the marker for a Burp
Collaborator beacon if you need out-of-band confirmation of execution.

## The variants

| # | File | Trigger | Fires when | Why it's separate |
|---|------|---------|-----------|-------------------|
| 1 | `pdfxss_1_openaction.pdf` | `/OpenAction → /JS` | Document opens | Most widely honoured; Adobe, Foxit, many server renderers |
| 2 | `pdfxss_2_names_javascript.pdf` | `/Names → /JavaScript` tree | Document loads | Document-level script; independent of OpenAction |
| 3 | `pdfxss_3_page_open_aa.pdf` | Page `/AA /O` | Page is displayed | Catches viewers that ignore OpenAction but run page actions |
| 4 | `pdfxss_4_widget_click.pdf` | Form widget mouse-up | User clicks the field | Survives sanitisers that only strip open-actions |
| 5 | `pdfxss_5_compressed_js.pdf` | `/OpenAction` + FlateDecode JS | Document opens | Tests scanners that grep plaintext for `app.alert` and miss compressed payloads |
| 6 | `pdfxss_6_uri_javascript.pdf` | `/OpenAction → /URI javascript:` | Document opens / link handled | Different bug class: hosting page reflecting a `javascript:` URI, not viewer JS |

## What a "pass" (i.e. a vulnerability) actually looks like

Uploading these and having them *stored* is **not** the finding. The finding is
**execution in a victim's context**. Be precise about where the popup fires,
because the severity is completely different:

- **Popup in a desktop PDF reader** (Adobe/Foxit) after download — proves the
  file carries active JS, but it executes in the *reader*, sandboxed and
  off-origin. Low severity on its own; document it as "stored PDF with active
  JavaScript", not as XSS against the web app.
- **Popup rendered in the browser, in the application's origin** — e.g. the app
  previews the PDF inline via a vulnerable pdf.js config, or reflects PDF
  content into the page — *that* is XSS against the web app, and the serious
  result. This is the one worth escalating, and only if it runs in a
  **different user's** session does it become high-impact stored XSS.
- **Nothing fires anywhere** — the renderer/sanitiser is doing its job for that
  trigger. Record it as tested-and-negative; that's a real result too.

## How to use them

1. Upload each variant through the target's file-upload feature.
2. Note whether the app accepts it, and how it stores/serves it back
   (attachment link, inline preview, thumbnail pipeline).
3. Open/preview each as the app would serve it, and record **where** — if
   anywhere — the popup appears (reader vs browser-in-origin).
4. For any that execute in-browser, confirm cross-user impact by viewing from a
   separate, lower-privilege account before rating severity.
5. Log every variant's result (fired / stored-inert / rejected) in your report
   so the coverage is auditable.

## Scope reminder

These are live test artifacts for an **authorised** engagement. Keep them out of
shared drives and email, use the benign marker (or your own Collaborator host),
and confirm the target is in your rules of engagement before uploading. If you
escalate to a Collaborator beacon, keep it non-destructive — you're proving
reach, not causing impact.
